# Tempo CLI ⏱️

**The Most Advanced Automatic Project Time Tracker**

A lightning-fast Rust-powered time tracking application that automatically detects your work context, tracks productivity across projects, and provides beautiful insights through an intuitive terminal interface.

## 🚀 Quick Install

```bash
# Install with uv (fastest)
uv install tempo-cli

# Or with pip
pip install tempo-cli

# Start tracking immediately
tempo start
tempo session start
```

## ✨ Features

- **🚀 Zero Setup** - Just install and start tracking
- **🧠 Intelligent** - Auto-detects Git repos and project contexts  
- **⚡ Lightning Fast** - Rust-powered with sub-millisecond response times
- **🎨 Beautiful** - Stunning terminal interface with color-coded contexts
- **🔄 Automatic** - Background tracking with goal progress updates
- **🌐 Universal** - Works on macOS, Linux, Windows

## 📋 Quick Commands

```bash
# Session Management
tempo start                    # Start tracking daemon  
tempo session start           # Begin tracking current project
tempo status                  # Show real-time status

# Project & Workspace Management
tempo list                    # List all projects
tempo workspace create Dev    # Create workspace
tempo goal create "Learn Rust" 40 --project my-app

# Analytics & Reports
tempo report                  # Beautiful terminal report
tempo dashboard              # Interactive dashboard
tempo insights --period week # Weekly productivity insights
```

## 🎯 Core Capabilities

### ⚡ **Smart Time Tracking**
- Automatic project detection (Git, package.json, Cargo.toml)
- Context-aware sessions (Terminal, IDE, linked projects)
- Background daemon with zero performance impact
- Intelligent pause/resume with idle detection

### 📊 **Advanced Project Management**
- **Workspace Organization** - Group related projects
- **Goal Tracking** - Set time targets with automatic progress
- **Tag System** - Categorize and filter projects
- **Project Templates** - Quick setup for similar projects

### 🔍 **Powerful Analytics**
- **Time Reports** - Daily, weekly, monthly with export options
- **Productivity Insights** - Track patterns and peak hours
- **Goal Progress** - Visual progress toward objectives  
- **Project Comparison** - Compare time allocation

## 🖥️ Interface Previews

### Real-Time Status
```
┌─────────────────────────────────────────┐
│               Daemon Status             │
├─────────────────────────────────────────┤
│ Status:   ● Online                      │
│ Uptime:   2h 15m 30s                    │
│                                         │
│ Active Session:                         │
│   Project: my-awesome-project           │
│   Duration: 45m 12s                     │
│   Context: terminal                     │
└─────────────────────────────────────────┘
```

### Goal Tracking
```
┌─────────────────────────────────────────┐
│                Goals                    │
├─────────────────────────────────────────┤
│ 🎯 Learn Rust                           │
│    Progress: 65.5% (26.2h / 40.0h)     │
│                                         │
│ 🎯 Ship v1.0                           │
│    Progress: 80.0% (32.0h / 40.0h)     │
└─────────────────────────────────────────┘
```

## 🛠️ Requirements

This package installs the Rust binary automatically via Cargo. You'll need:

- **Rust & Cargo**: Install from [rustup.rs](https://rustup.rs/)
- **Python 3.8+**: For the wrapper package

## 📂 Data Storage

All data stored locally for privacy:
- Database: `~/.tempo/data.db` (SQLite)
- Config: `~/.tempo/config.toml` 
- Socket: `~/.tempo/daemon.sock`

## 🔗 Links

- **Full Documentation**: [GitHub Repository](https://github.com/own-path/tempo)
- **Issues**: [Bug Reports](https://github.com/own-path/tempo/issues)
- **PyPI Package**: [tempo-cli](https://pypi.org/project/tempo-cli/)

## 📄 License

MIT License - Built with ❤️ for developers

---

*Track your time. Achieve your goals. Build amazing things.*